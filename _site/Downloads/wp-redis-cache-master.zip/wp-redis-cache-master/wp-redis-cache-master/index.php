<?php
require('index-wp-redis.php');
